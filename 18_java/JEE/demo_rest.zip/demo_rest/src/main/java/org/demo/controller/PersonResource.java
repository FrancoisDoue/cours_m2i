package org.demo.controller;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import org.demo.entity.Person;

@Path("/persons")
public class PersonResource {

    @GET
    @Path("/single")
    @Produces(MediaType.APPLICATION_JSON)
    public Person getPerson() {
        return new Person(1, "Georges", "Abitbol", 72);
    }
}
